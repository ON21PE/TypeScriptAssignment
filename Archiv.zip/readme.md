## How to get started

Type npm i to install dependencies inside of the project folder in the terminal.

Write any source files in typescript inside the source folder, the main file being index.ts as entry file for rollup.

Type tsc to javascript

Link your compiled bundle.js into your HTML-Files.



