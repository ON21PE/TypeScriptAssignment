// THIS IS A MODULE

export function alertMe(): void {
  alert("ATTENTION PLEASE");
}
