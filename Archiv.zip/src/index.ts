let zusammengerechnet: number;

const round = <HTMLInputElement>document.getElementById("rounds");
const time = <HTMLInputElement>document.getElementById("time");
const break_time = <HTMLInputElement>document.getElementById("break_time");
const div = <HTMLDivElement>document.getElementById("test");

const body = document.body;
const counter = document.createElement("div");
counter.innerText = "Bitte Zeit ausfüllen";
body.append(counter);

round.addEventListener("change", test);
time.addEventListener("change", test);
break_time.addEventListener("change", test);
function test() {
  console.log(round, time, break_time);
}
function start() {
  let pausen = parseInt(break_time.value);
  let zeit = parseInt(time.value);
  let runden = parseInt(round.value);
  console.log(runden);
  while (runden >= 0) {
    startTimer(zeit);
    if (zeit === 0) {
      console.log("Runde" + runden);
      startTimer(pausen);
      console.log("Pause" + runden);
      runden--;
    }
  }
  let calculated: any =
    parseInt(round.value) * (parseInt(time.value) + parseInt(break_time.value));
  zusammengerechnet = calculated;
  console.log(calculated);
}

// Startet Counter
let button = document.getElementById("startButton");
console.log(button);
button?.addEventListener("click", function () {
  start();
});

// Countdown
function startTimer(zeit: any) {
  console.log(zeit);
  counter.innerText = secondsToHms(zeit);

  window.setTimeout(function () {
    countdown(zeit);
  }, 1000);
}
function countdown(zeit: any) {
  zeit--;
  counter.innerText = secondsToHms(zeit);
  if (zeit != 0) {
    window.setTimeout(function () {
      countdown(zeit);
    }, 1000);
  }
}

function secondsToHms(d: any) {
  d = Number(d);

  var h = Math.floor(d / 3600);
  var m = Math.floor((d % 3600) / 60);
  var s = Math.floor((d % 3600) % 60);

  return (
    ("0" + h).slice(-2) + ":" + ("0" + m).slice(-2) + ":" + ("0" + s).slice(-2)
  );
}
